var G_Error = '<?error found?>';
var G_MAC	= '<?get :InternetGatewayDevice.DeviceInfo.SerialNumber ?>'; 
var G_CheckReset   = '<?get :InternetGatewayDevice.DeviceInfo.X_TWSZ-COM_FactoryMode ?>'; 
var G_CMDProtest = "";
var G_CMDStatus = "";
